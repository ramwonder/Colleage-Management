package com.example.CloudApiGatewayDepStu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudApiGatewayDepStuApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudApiGatewayDepStuApplication.class, args);
	}

}
