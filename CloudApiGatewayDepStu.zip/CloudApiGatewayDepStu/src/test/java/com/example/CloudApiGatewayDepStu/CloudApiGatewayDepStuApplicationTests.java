package com.example.CloudApiGatewayDepStu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudApiGatewayDepStuApplicationTests {

	@Test
	void contextLoads() {
	}

}
